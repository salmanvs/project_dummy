package card_dummy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import databaseConnection.*;

import card_dummy.CardDAO;

public class CardDAO {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(Databaseconnection.driverClass);
			con = DriverManager.getConnection(Databaseconnection.connectionUrl,Databaseconnection.username,Databaseconnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;

	}

	 public static int save(Card e){  
	        int status=0;  
	        try{  
	            Connection con=CardDAO.getConnection();  
	            PreparedStatement ps=con.prepareStatement("insert into card_details(card_details_card_holder_name,card_details_card_no,card_details_parent_bank,card_details_linked_mobile_no) values (?,?,?,?)");  
	            ps.setString(1,e.getCard_holder_name());  
	            ps.setString(2,e.getCard_number());  
	            ps.setString(3,e.getBank_name());  
	            ps.setString(4,e.getMobile_number());  
	              
	            status=ps.executeUpdate();  
	              
	            con.close();  
	        }catch(Exception ex){ex.printStackTrace();}  
	          
	        return status;  
	    }  

}
