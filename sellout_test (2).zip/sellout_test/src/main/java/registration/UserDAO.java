package registration;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

import registration.User;
import registration.UserDAO;
import databaseConnection.*;
public class UserDAO {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(Databaseconnection.driverClass);
			con = DriverManager.getConnection(Databaseconnection.connectionUrl,Databaseconnection.username,Databaseconnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;

	}

	 public static int save(User e){  
	        int status=0;  
	        try{  
	            Connection con=UserDAO.getConnection();  
	            PreparedStatement ps=con.prepareStatement("insert into user_registration(user_registration_email,user_registration_password) values (?,?)");  
	            
	            ps.setString(1,e.getEmail());
	            ps.setString(2,e.getPassword());  
  
	              
	              
	            status=ps.executeUpdate();  
	              
	            con.close();  
	        }catch(Exception ex){ex.printStackTrace();}  
	          
	        return status;  
	    }

}
