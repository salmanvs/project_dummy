package matchdetails;

public class Matchdetails {
	private int id;
	private String match_details_match_name,match_details_stadium_name,match_details_match_date,match_details_match_time,match_details_match_discription;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMatch_details_match_name() {
		return match_details_match_name;
	}
	public void setMatch_details_match_name(String match_details_match_name) {
		this.match_details_match_name = match_details_match_name;
	}
	public String getMatch_details_stadium_name() {
		return match_details_stadium_name;
	}
	public void setMatch_details_stadium_name(String match_details_stadium_name) {
		this.match_details_stadium_name = match_details_stadium_name;
	}
	public String getMatch_details_match_date() {
		return match_details_match_date;
	}
	public void setMatch_details_match_date(String match_details_match_date) {
		this.match_details_match_date = match_details_match_date;
	}
	public String getMatch_details_match_time() {
		return match_details_match_time;
	}
	public void setMatch_details_match_time(String match_details_match_time) {
		this.match_details_match_time = match_details_match_time;
	}
	public String getMatch_details_match_discription() {
		return match_details_match_discription;
	}
	public void setMatch_details_match_discription(String match_details_match_discription) {
		this.match_details_match_discription = match_details_match_discription;
	}

}
