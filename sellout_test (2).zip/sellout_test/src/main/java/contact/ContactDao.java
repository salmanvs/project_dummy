package contact;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import databaseConnection.Databaseconnection;
import contact.Contact;

public class ContactDao {
	public static Connection getConnection() {

		Connection con = null;
		try {
			Class.forName(Databaseconnection.driverClass);
			con = DriverManager.getConnection(Databaseconnection.connectionUrl,Databaseconnection.username,Databaseconnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
	
		return con;

}
	public static int save(Contact u) {
		int status = 0;
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement("insert into contact_us(contact_us_name,contact_us_email,contact_us_message) values(?,?,?)");
			ps.setString(1,u.getContact_us_name());
			ps.setString(2,u.getContact_us_email());
			ps.setString(3,u.getContact_us_message());
			
			status = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

}
