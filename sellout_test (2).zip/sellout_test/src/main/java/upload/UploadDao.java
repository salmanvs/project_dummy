package upload;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

import databaseConnection.Databaseconnection;
import registration.User;
import registration.UserDAO;

public class UploadDao {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(Databaseconnection.driverClass);
			con = DriverManager.getConnection(Databaseconnection.connectionUrl,Databaseconnection.username,Databaseconnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;

	}

	 public static int save(Upload_been e){  
	        int status=0;  
	        try{  
	            Connection con=UploadDao.getConnection();  
	            PreparedStatement ps=con.prepareStatement("insert into profile_pic(profile_pic_pic) values (?)");  
	            
	            ps.setBlob(1,e.getUser_details_add_profile_picture());
	              
  
	              
	              
	            status=ps.executeUpdate();  
	              
	            con.close();  
	        }catch(Exception ex){ex.printStackTrace();}  
	          
	        return status;  
	    }


}
